
# Stayton Solutions Feature Pack

Drop-in extras for **Stayton Credit Solutions** to stand out:

## What’s inside
- ✅ **Head SEO/PWA snippet** — copy `head-snippet.html` into your `<head>`
- ✅ **Interactive features** — `features.html` section (calculator + dispute letter + FAQ + accessibility)
- ✅ **Sticky CTA + Back-to-top**
- ✅ **PWA** — `manifest.webmanifest` and `service-worker.js`
- ✅ **Social previews** — `assets/img/og-card.png`
- ✅ **Sitemap & robots** — `sitemap.xml`, `robots.txt`
- ✅ **Styles & JS** — `assets/css/features.css`, `assets/js/feature-pack.js`

## Add to your site
1) Copy the **/assets** folder to your project root.
2) In `<head>`, paste the contents of **head-snippet.html**.
3) In your `<body>`, paste **features.html** where you want the block.
4) Place `sitemap.xml` and `robots.txt` in the site root (same level as index.html).
5) Upload everything to GitHub Pages (or your host).

## Enable PWA (optional)
Add this near the bottom of your `<body>`:
```html
<script>
  if ('serviceWorker' in navigator) { navigator.serviceWorker.register('/service-worker.js'); }
</script>
```

## Replace placeholders
- Update `https://staytoncreditrepair.github.io` to your actual site URL in `head-snippet.html`, `sitemap.xml`, and `robots.txt`.
- Images live under `/assets/img/`. Replace with your own if you want.
- Colors: tweak in `assets/css/features.css`.

— Built 2025-11-08
