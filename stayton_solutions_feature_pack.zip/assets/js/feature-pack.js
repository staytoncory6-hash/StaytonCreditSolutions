
// Stayton Solutions Feature Pack — feature-pack.js
(function() {
  // Back-to-top
  const topBtn = document.querySelector('.back-to-top');
  if (topBtn) {
    window.addEventListener('scroll', () => {
      topBtn.style.display = window.scrollY > 300 ? 'inline-block' : 'none';
    });
  }

  // Accessibility
  const html = document.documentElement;
  const contrastBtn = document.querySelector('.contrast-toggle');
  const fontUpBtn = document.querySelector('.fontup');
  const fontDownBtn = document.querySelector('.fontdown');

  let baseSize = 16;
  if (contrastBtn) contrastBtn.addEventListener('click', () => html.classList.toggle('high-contrast'));
  if (fontUpBtn) fontUpBtn.addEventListener('click', () => { baseSize = Math.min(22, baseSize+1); html.style.fontSize = baseSize + 'px'; });
  if (fontDownBtn) fontDownBtn.addEventListener('click', () => { baseSize = Math.max(14, baseSize-1); html.style.fontSize = baseSize + 'px'; });

  // High contrast style
  const hc = document.createElement('style');
  hc.innerHTML = `html.high-contrast, html.high-contrast body { background:#000 !important; color:#fff !important; }
  html.high-contrast a { color: #d4af37; } html.high-contrast .feature-card { background:#111 !important; color:#fff !important; }
  html.high-contrast input, html.high-contrast textarea { background:#000; color:#fff; border-color:#666; }`;
  document.head.appendChild(hc);

  // FAQ accordion
  document.querySelectorAll('.faq dt').forEach(dt => {
    dt.addEventListener('click', () => {
      const dd = dt.nextElementSibling;
      dd.style.display = dd.style.display === 'block' ? 'none' : 'block';
    });
  });

  // Credit Utilization Calculator
  const utilForm = document.getElementById('util-form');
  if (utilForm) {
    utilForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const balance = parseFloat(document.getElementById('util-balance').value || '0');
      const limit = parseFloat(document.getElementById('util-limit').value || '0');
      const pct = limit > 0 ? (balance/limit*100) : 0;
      const out = document.getElementById('util-output');
      out.textContent = pct.toFixed(1) + '%';
    });
  }

  // Dispute Letter Generator -> downloadable text
  const disputeForm = document.getElementById('dispute-form');
  if (disputeForm) {
    disputeForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const name = document.getElementById('d-name').value.trim();
      const addr = document.getElementById('d-addr').value.trim();
      const bureau = document.getElementById('d-bureau').value.trim();
      const acct = document.getElementById('d-acct').value.trim();
      const reason = document.getElementById('d-reason').value.trim();

      const today = new Date().toISOString().slice(0,10);
      const body = `Date: ${today}\n\n${bureau}\n\nRe: Dispute of Inaccurate Credit Information (Account: ${acct})\n\nDear Sir or Madam,\n\nI, ${name}, at ${addr}, dispute the accuracy of the information reported for the account referenced above. Reason: ${reason}.\n\nUnder the FCRA, please investigate and correct or delete the item within 30 days and provide me the results of your investigation. Enclosed are any supporting documents.\n\nSincerely,\n${name}`;

      const blob = new Blob([body], {type: 'text/plain'});
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = 'dispute_letter.txt';
      a.click();
      URL.revokeObjectURL(url);
    });
  }

  // Sticky CTA tracking (simple)
  window.addEventListener('load', () => {
    document.querySelectorAll('.sticky-cta a').forEach(a => a.addEventListener('click', () => {
      console.log('CTA clicked:', a.href);
    }));
  });
})();
