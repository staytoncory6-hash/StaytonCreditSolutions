
self.addEventListener('install', e => {
  e.waitUntil(caches.open('stayton-v1').then(cache => cache.addAll(['/','/assets/css/features.css','/assets/js/feature-pack.js'])));
});
self.addEventListener('fetch', e => {
  e.respondWith(caches.match(e.request).then(resp => resp || fetch(e.request)));
});
